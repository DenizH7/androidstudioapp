package com.example.myapplicationbruhani2;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    TextView tryText;
    TextView cadText;
    TextView usdText;
    TextView jpyText;
    TextView chfText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tryText = findViewById(R.id.tryText);
        cadText = findViewById(R.id.cadText);
        usdText = findViewById(R.id.usdText);
        jpyText = findViewById(R.id.jpyText);
        chfText = findViewById(R.id.chfText);
    }

    public void getRates(View view) {
        DownloadData downloadData = new DownloadData();
        String url = "http://data.fixer.io/api/latest?access_key=022b72a56538e204d353c79756acefc4&format=1";
        downloadData.execute(url);
    }

    private class DownloadData extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {
            String result = "";
            HttpURLConnection httpURLConnection;
            try {
                URL url = new URL(strings[0]);
                httpURLConnection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = httpURLConnection.getInputStream();
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                int data = inputStreamReader.read();
                while (data > 0) {
                    char character = (char) data;
                    result += character;
                    data = inputStreamReader.read();
                }
                return result;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONObject jsonObject = new JSONObject(s);
                String base = jsonObject.getString("base");
                JSONObject jsonObject1 = jsonObject.getJSONObject("rates");
                String turkishlira = jsonObject1.getString("TRY");
                tryText.setText("TRY: " + turkishlira);
                String usd = jsonObject1.getString("USD");
                usdText.setText("USD: " + usd);
                String cad = jsonObject1.getString("CAD");
                cadText.setText("CAD: " + cad);
                String chf = jsonObject1.getString("CHF");
                chfText.setText("CHF: " + chf);
                String jpy = jsonObject1.getString("JPY");
                jpyText.setText("JPY: " + jpy);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
